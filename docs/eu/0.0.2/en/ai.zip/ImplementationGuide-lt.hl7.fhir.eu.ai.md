# Resource HL7 Europe IG Snapshot



## Resource Content

```json
{
  "resourceType" : "ImplementationGuide",
  "id" : "lt.hl7.fhir.eu",
  "language" : "en",
  "url" : "https://hl7.lt/fhir/eu/ImplementationGuide/lt.hl7.fhir.eu",
  "version" : "0.0.2",
  "name" : "Hl7Eu",
  "title" : "HL7 Europe IG Snapshot",
  "status" : "draft",
  "date" : "2026-03-15T21:19:00+02:00",
  "publisher" : "Lithuanian Medical Library",
  "contact" : [{
    "name" : "Lithuanian Medical Library",
    "telecom" : [{
      "system" : "url",
      "value" : "https://medicinosnk.lt"
    },
    {
      "system" : "email",
      "value" : "info@medicinosnk.lt"
    }]
  }],
  "description" : "The copy of the Laboratory Report and Imaging Report Implementation Guide, to enable them for development of the Lithuanian Implementation Guides. The content is based on the HL7 Europe IGs. This IG should be removed after publication of the official IG-s.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "EU"
    }]
  }],
  "packageId" : "lt.hl7.fhir.eu",
  "license" : "CC0-1.0",
  "fhirVersion" : ["5.0.0"],
  "dependsOn" : [{
    "id" : "hl7ext",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on the HL7 Extension Pack"
    }],
    "uri" : "http://hl7.org/fhir/extensions/ImplementationGuide/hl7.fhir.uv.extensions",
    "packageId" : "hl7.fhir.uv.extensions.r5",
    "version" : "5.2.0"
  },
  {
    "id" : "hl7_terminology_r5",
    "uri" : "http://terminology.hl7.org/ImplementationGuide/hl7.terminology",
    "packageId" : "hl7.terminology.r5",
    "version" : "7.1.0"
  },
  {
    "id" : "hl7_fhir_eu_base_r5",
    "uri" : "http://hl7.eu/fhir/base-r5/ImplementationGuide/hl7.fhir.eu.base-r5",
    "packageId" : "hl7.fhir.eu.base-r5",
    "version" : "0.1.0"
  },
  {
    "id" : "hl7_fhir_eu_extensions_r5",
    "uri" : "http://hl7.eu/fhir/extensions/ImplementationGuide/hl7.fhir.eu.extensions",
    "packageId" : "hl7.fhir.eu.extensions.r5",
    "version" : "1.2.0"
  }],
  "definition" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-internal-dependency",
      "valueCode" : "hl7.fhir.uv.tools.r5#0.9.0"
    }],
    "grouping" : [{
      "id" : "GroupA",
      "name" : "HL7 EU Base profiles",
      "description" : "Temporary copy of the EU profiles"
    },
    {
      "id" : "GroupB",
      "name" : "HL7 EU Imaging profiles",
      "description" : "HL7 EU Imaging profiles"
    },
    {
      "id" : "GroupC",
      "name" : "EU Lab profiles",
      "description" : "EU Lab profiles"
    },
    {
      "id" : "GroupD",
      "name" : "IPS data types",
      "description" : "IPS data types"
    }],
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:complex-type"
      }],
      "reference" : {
        "reference" : "StructureDefinition/CodeableConcept-uv-ips"
      },
      "name" : "Codeable Concept (IPS)",
      "description" : "This profile represents the constraint applied to the CodeableConcept data type by the International Patient Summary (IPS) FHIR Implementation Guide to use the Coding-uv-ips data type profile.",
      "isExample" : false,
      "groupingId" : "GroupD"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:complex-type"
      }],
      "reference" : {
        "reference" : "StructureDefinition/Coding-uv-ips"
      },
      "name" : "Coding with translations (IPS)",
      "description" : "This profile extends the capabilities of the coding data type to support multi-language designations (display).\nIt relies on the Translation extension.",
      "isExample" : false,
      "groupingId" : "GroupD"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/Composition-eu-lab"
      },
      "name" : "Composition: Laboratory Report (Eu Lab)",
      "description" : "Clinical document used to represent a Laboratory Report for the scope of the HL7 Europe project.",
      "isExample" : false,
      "groupingId" : "GroupC"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DiagnosticReport-eu-lab"
      },
      "name" : "DiagnosticReport: Laboratory Report (Eu Lab)",
      "description" : "DiagnosticReport used to represent an entry of a Laboratory Report, including its context, for the scope of the HL7 Europe project.",
      "isExample" : false,
      "groupingId" : "GroupC"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/CarePlanEu"
      },
      "name" : "EU CarePlan",
      "description" : "Care plan for the patient. \nContains the narrative containing the plan including proposals, goals, and order requests for monitoring, tracking, or improving the condition of the patient. In the future it is expected that the care plan could be provided in a structured and coded format.",
      "isExample" : false,
      "groupingId" : "GroupA"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/CompositionEu"
      },
      "name" : "EU Composition",
      "description" : "Clinical document used to represent a report for the scope of the HL7 Europe project.",
      "isExample" : false,
      "groupingId" : "GroupA"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ConditionEu"
      },
      "name" : "EU Condition",
      "description" : "A condition profile for the EU.",
      "isExample" : false,
      "groupingId" : "GroupA"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DocumentReferenceEu"
      },
      "name" : "EU DocumentReference",
      "description" : "A DocumentReference profile for the EU.",
      "isExample" : false,
      "groupingId" : "GroupA"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/EndpointEu"
      },
      "name" : "EU Endpoint",
      "description" : "The FHIR endpoint resource with EU specific references.",
      "isExample" : false,
      "groupingId" : "GroupA"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/CrossVersionMediaViewExtension"
      },
      "name" : "EU Media.view extension",
      "description" : "This cross version extension includes the FHIR R4 version of the Media.view field which has at this point in time (April 18, 2025), not yet been included in the extension pack.",
      "isExample" : false,
      "groupingId" : "GroupA"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ObservationEu"
      },
      "name" : "EU Observation",
      "description" : "A observation profile for the EU.",
      "isExample" : false,
      "groupingId" : "GroupA"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ProcedureEu"
      },
      "name" : "EU Procedure",
      "description" : "A procedure profile for the EU.",
      "isExample" : false,
      "groupingId" : "GroupA"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:complex-type"
      }],
      "reference" : {
        "reference" : "StructureDefinition/quantity-eu"
      },
      "name" : "EU Quantity",
      "description" : "A quantity profile for the EU.",
      "isExample" : false,
      "groupingId" : "GroupA"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:complex-type"
      }],
      "reference" : {
        "reference" : "StructureDefinition/range-eu"
      },
      "name" : "EU Range",
      "description" : "A range profile for the EU.",
      "isExample" : false,
      "groupingId" : "GroupA"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:complex-type"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SimpleQuantityEu"
      },
      "name" : "EU SimpleQuantity",
      "description" : "A simple quantity profile for the EU.",
      "isExample" : false,
      "groupingId" : "GroupA"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/composition-diagnosticReportReference"
      },
      "name" : "Extension: Document DiagnosticReport Reference (Eu Lab)",
      "description" : "This extension provides a reference to the DiagnosticReport instance that is associated with this Composition.",
      "isExample" : false,
      "groupingId" : "GroupC"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/specimen-container-type"
      },
      "name" : "Extension: Specimen Container Type",
      "description" : "Type of container used for the specimen.",
      "isExample" : false,
      "groupingId" : "GroupC"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ImComposition"
      },
      "name" : "IM Composition",
      "description" : "Clinical document used to represent a Imaging Study Report for the scope of the HL7 Europe project.",
      "isExample" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ImDiagnosticReport"
      },
      "name" : "IM Diagnostic Report",
      "description" : "Diagnostic Report profile for Imaging Reports. This document represents the report of an imaging study. It is the anchor resource that refers to all structured data as well as the `Composition` resource that contains the narrative text of the report.",
      "isExample" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/im-composition-diagnosticReportReference"
      },
      "name" : "IM Document DiagnosticReport Reference",
      "description" : "This extension provides a reference to the DiagnosticReport instance that is associated with this Composition.",
      "isExample" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ImFinding"
      },
      "name" : "IM Finding",
      "description" : "Finding during imaging procedure.",
      "isExample" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ImImageIidViewerEndpoint"
      },
      "name" : "IM Image Viewer Endpoint",
      "description" : "This profile defines a placeholder for an Endpoint for a viewer that can be used to access the study, serie it is present on.\nThe application is based on [IHE-IID](https://www.ihe.net/uploadedFiles/Documents/Radiology/IHE_RAD_Suppl_IID.pdf).",
      "isExample" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:complex-type"
      }],
      "reference" : {
        "reference" : "StructureDefinition/im-accession-number-identifier"
      },
      "name" : "IM Imaging Accession Number Identifier",
      "description" : "This profile on Identifier represents the Accession Number for the Imaging Order.",
      "isExample" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ImImagingDevice"
      },
      "name" : "IM Imaging Device",
      "description" : "The device the made the image.",
      "isExample" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ImOrder"
      },
      "name" : "IM Imaging Order",
      "description" : "This profile on ServiceRequest represents the order for the Imaging Study and report.",
      "isExample" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ImProcedure"
      },
      "name" : "IM Imaging Procedure",
      "description" : "This profile on Procedure represents the imaging procedure.",
      "isExample" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ImImagingSelection"
      },
      "name" : "IM Imaging Selection",
      "description" : "Imaging Selection",
      "isExample" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ImImagingStudy"
      },
      "name" : "IM Imaging Study",
      "description" : "This profile represents an imaging study instance.",
      "isExample" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/instance-description"
      },
      "name" : "IM Instance Description",
      "description" : "A description of the instance in an ImagingStudy.",
      "isExample" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ImKeyImageDocumentReference"
      },
      "name" : "IM Key Image Document Reference",
      "description" : "A document containing key images for a patient. It can refer to a DICOM or non-DICOM image. When referring to a DICOM image, the DocumentReference.content.attachment.url should be a WADO-URI. When referring to a non-DICOM image, the DocumentReference.content.attachment.url should be a direct URL to the image.\n\nWhen the resource represents a DICOM instance it SHALL contain a the SOP Instance UID in the identifier element. When the resource represents a DICOM series it SHALL contain the Series Instance UID in the identifier element.",
      "isExample" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ImKeyImageImagingSelection"
      },
      "name" : "IM Key images represented as an ImagingSelection",
      "description" : "Key images represented as an ImagingSelection",
      "isExample" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:complex-type"
      }],
      "reference" : {
        "reference" : "StructureDefinition/im-study-instance-uid-identifier"
      },
      "name" : "IM Study Instance UID Identifier",
      "description" : "This profile on Identifier represents the Study Instance UID (0020,000D) for the Imaging Order.",
      "isExample" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ImWadoEndpoint"
      },
      "name" : "IM WADO Endpoint",
      "description" : "This profile defines the WADO endpoint for accessing imaging study content.",
      "isExample" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/location-eu-core"
      },
      "name" : "Location (EU core)",
      "description" : "This profile sets minimum expectations for the Location resource to be used for the purpose of this guide.",
      "isExample" : false,
      "groupingId" : "GroupA"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/medicalTestResult-eu-core"
      },
      "name" : "MedicalTestResult (EU core)",
      "description" : "This profile sets minimum expectations for the Observation resource for Medical Test Results common to most of the use cases.",
      "isExample" : false,
      "groupingId" : "GroupA"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/Observation-resultslab-eu-lab"
      },
      "name" : "Observation Results: laboratory (Eu Lab)",
      "description" : "This profile constrains the Observation resource to represent results produced by laboratory tests or panels/studies for the  HL7 Europe project.\nThis observation may represent the result of a simple laboratory test such as hematocrit or it may group the set of results produced by a multi-test study or panel such as a complete blood count, a dynamic function test, a urine specimen study. In the latter case, the observation carries the overall conclusion of the study and or a global interpretation by the producer of the study, in the comment element; and references the atomic results of the study as \"has-member\" child observations.",
      "isExample" : false,
      "groupingId" : "GroupC"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:complex-type"
      }],
      "reference" : {
        "reference" : "StructureDefinition/Quantity-eu-lab"
      },
      "name" : "Quantity (Eu Lab)",
      "description" : "This profile constrains the Quantity data type to use UCUM as the code system for units and optionally share measurement uncertainty",
      "isExample" : false,
      "groupingId" : "GroupD"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:complex-type"
      }],
      "reference" : {
        "reference" : "StructureDefinition/Quantity-uv-ips"
      },
      "name" : "Quantity (IPS)",
      "description" : "Data type Quantity constrained to use UCUM as the code system for units",
      "isExample" : false,
      "groupingId" : "GroupD"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:complex-type"
      }],
      "reference" : {
        "reference" : "StructureDefinition/Range-uv-ips"
      },
      "name" : "Range (IPS)",
      "description" : "Range constrained to UCUM as the code system for units.",
      "isExample" : false,
      "groupingId" : "GroupD"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:complex-type"
      }],
      "reference" : {
        "reference" : "StructureDefinition/Ratio-eu-lab"
      },
      "name" : "Ratio (Eu Lab)",
      "description" : "This profile constrains the Ratio data type to use UCUM as the code system for units and optionally share measurement uncertainty",
      "isExample" : false,
      "groupingId" : "GroupD"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:complex-type"
      }],
      "reference" : {
        "reference" : "StructureDefinition/Ratio-uv-ips"
      },
      "name" : "Ratio (IPS)",
      "description" : "Ratio data type, constrained to use UCUM as the code system for units.",
      "isExample" : false,
      "groupingId" : "GroupD"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/report-code"
      },
      "name" : "Report Code",
      "description" : "Diagnostic report codes including all subtypes of Clinical procedure report, excluding the root concept itself.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ServiceRequest-eu-lab"
      },
      "name" : "ServiceRequest: Laboratory Order (Eu Lab)",
      "description" : "This profile defines how to represent an laboratory orders using the HL7 FHIR ServiceRequest for the purpose of this guide.",
      "isExample" : false,
      "groupingId" : "GroupC"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:complex-type"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SimpleQuantity-uv-ips"
      },
      "name" : "SimpleQuantity (IPS)",
      "description" : "Data type profile SimpleQuantity constrained to use UCUM as the code system for units",
      "isExample" : false,
      "groupingId" : "GroupD"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/Specimen-eu-lab"
      },
      "name" : "Specimen: Laboratory (Eu Lab)",
      "description" : "This profile defines how to represent Specimens in HL7 FHIR for the purpose of this guide.",
      "isExample" : false,
      "groupingId" : "GroupC"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/Substance-additive-eu-lab"
      },
      "name" : "Substance: Specimen Additive Substance (Eu Lab)",
      "description" : "This profile defines how to represent Specimen Additive Substances in HL7 FHIR for the purpose of this guide.",
      "isExample" : false,
      "groupingId" : "GroupC"
    }],
    "page" : {
      "sourceUrl" : "toc.html",
      "name" : "toc.html",
      "title" : "Table of Contents",
      "generation" : "html",
      "page" : [{
        "sourceUrl" : "index.html",
        "name" : "index.html",
        "title" : "Home",
        "generation" : "markdown"
      }]
    },
    "parameter" : [{
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "copyrightyear"
      },
      "value" : "2025+"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "releaselabel"
      },
      "value" : "ci-build"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "special-url-base"
      },
      "value" : "https://hl7.eu/fhir"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "special-url"
      },
      "value" : "https://terminology.hl7.lt/fhir"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "excludettl"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "shownav"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "pin-canonicals"
      },
      "value" : "pin-all"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-version"
      },
      "value" : "false"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "default-version"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "i18n-default-lang"
      },
      "value" : "en"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "i18n-lang"
      },
      "value" : "lt"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "translation-sources"
      },
      "value" : "input/translations/lt"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "autoload-resources"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/capabilities"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/examples"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/extensions"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/models"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/operations"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/profiles"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/resources"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/vocabulary"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/maps"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/testing"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/history"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "fsh-generated/resources"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-pages"
      },
      "value" : "template/config"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-pages"
      },
      "value" : "input/assets"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-pages"
      },
      "value" : "input/images"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-liquid"
      },
      "value" : "template/liquid"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-liquid"
      },
      "value" : "input/liquid"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-qa"
      },
      "value" : "temp/qa"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-temp"
      },
      "value" : "temp/pages"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-output"
      },
      "value" : "output"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-tx-cache"
      },
      "value" : "input-cache/txcache"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-suppressed-warnings"
      },
      "value" : "input/ignoreWarnings.txt"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-history"
      },
      "value" : "https://hl7.lt/fhir/eu/history.html"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "template-html"
      },
      "value" : "template-page.html"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "template-md"
      },
      "value" : "template-page-md.html"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-contact"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-context"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-copyright"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-jurisdiction"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-license"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-publisher"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-wg"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "active-tables"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "fmm-definition"
      },
      "value" : "http://hl7.org/fhir/versions.html#maturity"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "propagate-status"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "excludelogbinaryformat"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "tabbed-snapshots"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "wantGen-ttl"
      },
      "value" : "false"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "wantGen-ttl-html"
      },
      "value" : "false"
    }]
  }
}

```
