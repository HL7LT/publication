# Artefaktų santrauka - Lithuanian Base Implementation Guide v0.1.0

## Artefaktų santrauka

 
Dabartiniam puslapiui nėra vertimo puslapio, todėl jis pateiktas numatytąja kalba 

