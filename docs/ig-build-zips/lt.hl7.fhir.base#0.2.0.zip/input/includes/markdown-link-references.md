[Data Absent Reason]: https://hl7.org/fhir/extensions/StructureDefinition-data-absent-reason.html
[Must Support]: {{site.data.fhir.path}}profiling.html#mustsupport
[validating profiles and resources]: {{site.data.fhir.path}}validation.html
