# Body Height observation codes - Lithuanian Vital Signs Implementation Guide v0.0.1

## ValueSet: Body Height observation codes 

 
This value set defines the set of LOINC codes considered to be appropriate for representing body height (including body length) vital sign measurements in Observation.code. 

 **References** 

* [Body Height](StructureDefinition-body-height.md)

### Logical Definition (CLD)

Last updated: 2025-10-26 17:42:56+0000; Language: en

Profile: [Shareable ValueSetversion: null5.0.0)](http://hl7.org/fhir/R5/shareablevalueset.html)

This value set includes codes based on the following rules:

* Include codes from[`http://loinc.org`](http://loinc.org)version Not Stated (use latest from terminology server) where CLASS in LP7768-7,LP7769-5, PROPERTY = LP6822-3 (Len), TIME_ASPCT = LP6960-1 (Pt), SYSTEM = LP310005-6 (^Patient) and SCALE_TYP = LP7753-9 (Qn)

This value set excludes codes based on the following rules:

* Exclude codes from[`http://loinc.org`](http://loinc.org)version Not Stated (use latest from terminology server) where COMPONENT = LP343922-3 (Upper segment)
* Exclude codes from[`http://loinc.org`](http://loinc.org)version Not Stated (use latest from terminology server) where COMPONENT = LP343921-5 (Lower segment)

 

### Išplėtimas

Expansion from tx.fhir.org based on Loinc v2.81

This value set contains 9 concepts

-------

 [Aukščiau pateiktos(-ų) lentelės(-ių) aprašymas(-ai)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "body-height-observation",
  "meta" : {
    "lastUpdated" : "2025-10-26T17:42:56.640+00:00",
    "profile" : [
      "http://hl7.org/fhir/StructureDefinition/shareablevalueset|5.0.0"
    ]
  },
  "language" : "en",
  "extension" : [
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-wg",
      "valueCode" : "oo"
    }
  ],
  "url" : "https://hl7.lt/fhir/vitalsigns/ValueSet/body-height-observation",
  "version" : "6.0.0",
  "name" : "BodyHeightObservation",
  "title" : "Body Height observation codes",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-11-19T15:54:38+02:00",
  "publisher" : "Lithuanian Medical Library",
  "_publisher" : {
    "extension" : [
      {
        "extension" : [
          {
            "url" : "lang",
            "valueCode" : "lt"
          },
          {
            "url" : "content",
            "valueString" : "Lietuvos medicinos biblioteka"
          }
        ],
        "url" : "http://hl7.org/fhir/StructureDefinition/translation"
      }
    ]
  },
  "contact" : [
    {
      "name" : "Lithuanian Medical Library",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://medicinosnk.lt"
        },
        {
          "system" : "email",
          "value" : "info@medicinosnk.lt"
        }
      ]
    }
  ],
  "description" : "This value set defines the set of LOINC codes considered to be appropriate for representing body height (including body length) vital sign measurements in Observation.code.",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "LT"
        }
      ]
    }
  ],
  "copyright" : "This content from LOINC® is copyright © 1995 Regenstrief Institute, Inc. and the LOINC Committee, and available at no cost under the license at http://loinc.org/terms-of-use",
  "compose" : {
    "include" : [
      {
        "system" : "http://loinc.org",
        "filter" : [
          {
            "property" : "CLASS",
            "op" : "in",
            "value" : "LP7768-7,LP7769-5"
          },
          {
            "property" : "PROPERTY",
            "op" : "=",
            "value" : "LP6822-3"
          },
          {
            "property" : "TIME_ASPCT",
            "op" : "=",
            "value" : "LP6960-1"
          },
          {
            "property" : "SYSTEM",
            "op" : "=",
            "value" : "LP310005-6"
          },
          {
            "property" : "SCALE_TYP",
            "op" : "=",
            "value" : "LP7753-9"
          }
        ]
      }
    ],
    "exclude" : [
      {
        "system" : "http://loinc.org",
        "filter" : [
          {
            "property" : "COMPONENT",
            "op" : "=",
            "value" : "LP343922-3"
          }
        ]
      },
      {
        "system" : "http://loinc.org",
        "filter" : [
          {
            "property" : "COMPONENT",
            "op" : "=",
            "value" : "LP343921-5"
          }
        ]
      }
    ]
  }
}

```
