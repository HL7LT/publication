# Changelog - Lithuanian Base Implementation Guide v0.2.0

## Changelog

### In development

Canonical URLs have been changed to `https://hl7.lt/fhir/` for conformance resources and `https://tx.lmb.lt/fhir/` for terminology resources to accommodate future IGs, which will follow a pattern of `https://hl7.lt/fhir/<ig>`.

### Version 0.1.0

Lithuanian translations have been added.

