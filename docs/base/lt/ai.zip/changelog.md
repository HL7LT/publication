# Pakeitimų žurnalas - Lithuanian Base Implementation Guide v0.2.0

## Pakeitimų žurnalas

 
Šiame puslapyje pateikiami vertimai iš originalo kalbos, kuria buvo parašytas vadovas. Informaciją apie šiuos vertimus ir instrukcijas, kaip pateikti atsiliepimus apie vertimus, galite rasti[čia](translationinfo.md). 

### In Development

