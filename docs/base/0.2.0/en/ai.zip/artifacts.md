# Artifacts Summary - Lithuanian Base Implementation Guide v0.2.0

## Artifacts Summary

