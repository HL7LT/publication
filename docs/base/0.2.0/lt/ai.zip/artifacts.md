# Artefaktų santrauka - Lithuanian Base Implementation Guide v0.2.0

## Artefaktų santrauka

 
Dabartiniam puslapiui nėra vertimo puslapio, todėl jis pateiktas numatytąja kalba 

