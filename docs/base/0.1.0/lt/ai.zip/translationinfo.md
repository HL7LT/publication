# Translationinfo - Lithuanian Base Implementation Guide v0.1.0

## Translationinfo

 
Šiame puslapyje pateikiami vertimai iš originalo kalbos, kuria buvo parašytas vadovas. Informaciją apie šiuos vertimus ir instrukcijas, kaip pateikti atsiliepimus apie vertimus, galite rasti[čia](translationinfo.md). 

TO DO

